#include "Renderer.h"

void Renderer::render( GLuint MatrixID,GLuint vertexbuffer, GLuint colorbuffer,  glm::vec3 objPos)
{
	
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glVertexAttribPointer(
		0,
		3,
		GL_FLOAT,
		GL_FALSE,
		0,
		(void*)0
	);

	
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glVertexAttribPointer(
		1,                                // attribute. No particular reason for 1, but must match the layout in the shader.
		3,                                // size
		GL_FLOAT,                         // type
		GL_FALSE,                         // normalized?
		0,                                // stride
		(void*)0                          // array buffer offset
	);
	
	

	glm::mat4 moveObjPos = glm::mat4(1.0f);
	moveObjPos = glm::translate(moveObjPos, objPos);

	glm::mat4 moveCameraPos = glm::mat4(1.0f);
	moveCameraPos = glm::translate(moveCameraPos, cameraPos);

	glm::mat4 Projection = glm::perspective(glm::radians(45.0f), 4.0f / 3.0f, 0.1f, 100.0f);



	glm::mat4 View = glm::lookAt(
		glm::vec3(-5, 3, 5),
		glm::vec3(0, 0, 0),
		glm::vec3(0, 1, 0)
	);


	glm::mat4 To_World = glm::mat4(1.0f);

	glm::mat4 MVP = Projection * moveCameraPos * View * moveObjPos * To_World;

	glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
	glDrawArrays(GL_TRIANGLES, 0, 3 * 12);
	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
	
}

void Renderer::setCameraPos(float x, float y, float z)
{
	cameraPos = glm::vec3(-x, -y, -z);
}