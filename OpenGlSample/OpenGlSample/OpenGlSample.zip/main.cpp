#include "FileManager.h"
#include "Object.h"
#include "Renderer.h"
int main(void)
{
	FileManager::GetInstance()->tearUp();

	Object* cube = new Object("vertex_data.csv", "color_data.csv", "20151687_vs.shader", "20151687_fs.shader");
	
	cube->setPos(0, 0, 0);

	Object* human = new Object("vertex_data2.csv", "color_data.csv", "20151687_vs.shader", "20151687_fs.shader");
	
	human->setPos(2, 0, 3);

	Renderer* render = new Renderer();
	render->setCameraPos(2, 0, 0);

	do {

		FileManager::GetInstance()->RenderUp();
			
		render->render(cube->getMatrixID(), cube->getVertexBuffer(), cube->getColorBuffer(), cube->getObjPos());
				
		render->render(human->getMatrixID(), human->getVertexBuffer(), human->getColorBuffer(), human->getObjPos());
			

		FileManager::GetInstance()->RenderDown();
	} while (glfwGetKey(FileManager::GetInstance()->window, GLFW_KEY_ESCAPE) != GLFW_PRESS && glfwWindowShouldClose(FileManager::GetInstance()->window) == 0);
	FileManager::GetInstance()->tearDown();

	return 0;
}