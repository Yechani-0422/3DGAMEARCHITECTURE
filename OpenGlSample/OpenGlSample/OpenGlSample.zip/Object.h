#pragma once
#include "FileManager.h"


using namespace std;

class Object
{
private:
	glm::vec3 objPos;
	glm::vec3 cameraPos;

	GLuint vertexbuffer;
	GLuint colorbuffer;
	GLuint MatrixID;
public:
	Object(string str, string str1, const char* str2, const char* str3);
	~Object();

	GLuint getMatrixID();
	GLuint getVertexBuffer();
	GLuint getColorBuffer();

	void setPos(float x, float y, float z);

	glm::vec3 getObjPos();
};

