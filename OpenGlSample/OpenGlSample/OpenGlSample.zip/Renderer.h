#pragma once

#include "FileManager.h"

class Renderer
{
private:
	glm::vec3 cameraPos;
public:
	void render( GLuint MatrixID, GLuint vertexbuffer,GLuint colorbuffer,glm::vec3 objPos);
	void setCameraPos(float x, float y, float z);
};

