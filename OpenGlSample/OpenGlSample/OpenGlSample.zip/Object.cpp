#include "Object.h"



Object::Object(string str, string str1, const char* str2, const char* str3)
{



	FileManager::GetInstance()->programID = FileManager::GetInstance()->LoadShaders(str2, str3);

	MatrixID = glGetUniformLocation(FileManager::GetInstance()->programID, "MVP");


	glGenVertexArrays(1, &FileManager::GetInstance()->VertexArrayID);
	glBindVertexArray(FileManager::GetInstance()->VertexArrayID);

	
	vector<GLfloat> vertex_data = FileManager::GetInstance()->LoadCsv(str);


	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_data.size() * sizeof(GLfloat), vertex_data.data(), GL_STATIC_DRAW);

	vector<GLfloat> color_data = FileManager::GetInstance()->LoadCsv(str1);

	glGenBuffers(1, &colorbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glBufferData(GL_ARRAY_BUFFER, color_data.size() * sizeof(GLfloat), color_data.data(), GL_STATIC_DRAW);

	objPos=glm::vec3(0.0f,0.0f,0.0f);
	cameraPos = glm::vec3(0.0f, 0.0f, 0.0f);
}


Object::~Object()
{
}

GLuint Object::getMatrixID()
{
	return MatrixID;
}
GLuint Object::getVertexBuffer()
{
	return vertexbuffer;
}

GLuint Object::getColorBuffer()
{
	return colorbuffer;
}

void Object::setPos(float x, float y, float z)
{
	objPos = glm::vec3(x, y, z);
}

glm::vec3 Object::getObjPos()
{
	return objPos;
}